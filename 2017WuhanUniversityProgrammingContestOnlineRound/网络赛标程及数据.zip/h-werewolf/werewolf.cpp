#include <bits/stdc++.h>

using namespace std;

const int maxn = 2e6;
int num_circle = 0, vis[maxn], que[maxn], x[maxn];
bool in_cir[maxn];
vector<int> cir[maxn], vec[maxn];
pair<int, int> f[maxn], dp[maxn], val[maxn];

void get_circle(int st) {
  ++num_circle;
  for (++num_circle; !vis[st]; st = x[st]) {
    vis[st] = num_circle;
  }
  cir[num_circle].push_back(st);
  in_cir[st] = num_circle;
  for (int i = x[st]; i != st; i = x[i]) {
    cir[num_circle].push_back(i);
    in_cir[i] = 1;
  }
}

pair<int, int> bfs(int st) {
  int head = 0, tail = 1;
  que[head] = st;
  while (head < tail) {
    int cur = que[head++];
    for (int i = 0, sz = vec[cur].size(); i < sz; ++i) {
      int nex = vec[cur][i];
      if (!in_cir[nex]) {
        vis[nex] = num_circle;
        que[tail++] = nex;
      }
    }
  }
  for (int i = tail - 1; ~i; --i) {
    int cur = que[i];
    f[cur].second = 1;
    for (int j = 0, sz = vec[cur].size(); j < sz; ++j) {
      int nex = vec[cur][j];
      if (in_cir[nex]) {
        continue;
      }
      f[cur].first += max(f[nex].first, f[nex].second);
      f[cur].second += f[nex].first;
    }
  }
  return f[st];
}

int work(int st) {
  get_circle(st);
  int sz = cir[num_circle].size();
  for (int i = 0; i < sz; ++i) {
    val[i] = bfs(cir[num_circle][i]);
  }
  dp[1] = make_pair(val[0].first, 0x80000000);
  for (int i = 1; i < sz; ++i) {
    dp[i + 1] = make_pair(val[i].first + max(dp[i].first, dp[i].second), dp[i].first + val[i].second);
  }
  int ret = max(dp[sz].first, dp[sz].second);
  for (int i = 0; i < sz; ++i) {
    dp[i + 1] = make_pair(val[i].first + max(dp[i].first, dp[i].second), dp[i].first + val[i].second);
  }
  return max(ret, dp[sz].first);
}

int main() {
  int n, ans = 0;
  while (~scanf("%d", &n))
  {
    ans = num_circle = 0;
    for (int i = 1; i <= n; i++) {
      cir[i].clear();
      in_cir[i] = 0;
      x[i] = 0;
      f[i] = val[i] = make_pair(0, 0);
      vec[i].clear();
      vis[i] = 0;
    }
    for (int i = 1; i <= n; ++i) {
      scanf("%d", x + i);
      vec[x[i]].push_back(i);
    }
    for (int i = 1; i <= n; ++i) {
      if (vis[i]) {
        continue;
      }
      ans += work(i);
    }
    printf("%d\n", ans);
  }
  return 0;
}
