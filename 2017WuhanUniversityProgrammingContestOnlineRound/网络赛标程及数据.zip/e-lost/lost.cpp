#include <bits/stdc++.h>
using namespace std;
const int Size = 100;
const int MO = 1e9+7;
struct Matrix{
    long long m[Size][Size];
}r,s;
Matrix operator *(Matrix &a, Matrix &b){
    Matrix c;
    for(int i=0; i<Size; i++)
        for(int j=0; j<Size; j++){
            c.m[i][j] = 0;
            for(int k=0; k<Size; k++)
                (c.m[i][j] += a.m[i][k]*b.m[k][j])%=MO;
        }
    return c;
}
void Power(Matrix &p, Matrix &a, int b){
    for(Matrix q = a; b; b>>=1){
        if(b&1) p = p*q;
        q = q*q;
    }
}
int N,M,T,A,B;
int main()
{
    scanf("%d%d",&N,&M);
    for(int i=1; i<=M; i++){
        scanf("%d%d",&A,&B);
        if(A!=N) s.m[A][B] = 1;
        if(B!=N) s.m[B][A] = 1;
    }
    scanf("%d",&T);
    s.m[N][N] = 1;
    r.m[0][1] = 1;
    Power(r,s,T);
    printf("%d",(int)r.m[0][N]);
}
