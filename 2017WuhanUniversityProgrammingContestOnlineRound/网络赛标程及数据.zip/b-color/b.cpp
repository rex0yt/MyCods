#include <bits/stdc++.h>
using namespace std;

const int mod = 10000009;
const int maxn = 10000 + 5;
long long dp1[maxn][25], dp2[maxn];

vector<int> e[maxn];

int able[maxn][25], n, m;

void dfs(int u, int fa)
{
	for (int i = 1; i <= m; i++) dp1[u][i] = able[u][i];
	for (int v : e[u])
	{
		if (v == fa) continue;
		dfs(v, u);
		for (int i = 1; i <= m; i++)
			(dp1[u][i] *= (dp2[v] - dp1[v][i] + mod) % mod) %= mod;
	}
	for (int i = 1; i <= m; i++) dp2[u] += dp1[u][i];
	dp2[u] %= mod;
}

int main()
{
	int n;
	while (cin >> n >> m)
	{
		for (int i = 1; i <= n; i++) e[i].clear();
		memset(dp1, 0, sizeof(dp1[0]) * (n + 5));
		memset(dp2, 0, sizeof(dp2[0]) * (n + 5));
		for (int i = 1; i < n; i++)
		{
			int u, v;
			cin >> u >> v;
			e[u].push_back(v);
			e[v].push_back(u);
		}
		for (int i = 1; i <= n; i++)
			for (int j = 1; j <= m; j++) cin >> able[i][j];
		dfs(1, -1);
		cout << dp2[1] << endl;
	}
	return 0;
}
