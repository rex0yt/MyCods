#include <bits/stdc++.h>
using namespace std;
int main()
{
	//freopen("5.in", "w", stdout);
	int n, m, t;
	n = 2e3;
	m = 2e3;
	t = 2e5;
	printf("%d %d %d\n", n, m, t);
	srand(time(0));
	int x, y, r;
	while(t--)
	{
		x = rand() % n + 1;
		y = rand() % m + 1;
		int lim = min(min(x - 1, n - x), min(y - 1, m - y));
		r = rand() % (lim + 1);
		printf("%d %d %d\n", x, y, r);
	}
	return 0;
}
