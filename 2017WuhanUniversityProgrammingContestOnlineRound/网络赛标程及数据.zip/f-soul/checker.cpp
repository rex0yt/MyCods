#include <bits/stdc++.h>
using namespace std;
const int N = 2010;
int cnt[N][N];
int ans1, ans2;
int n, m, t;
int main()
{
	//freopen("5.in", "r", stdin);
	//freopen("5.ans", "w", stdout);
	scanf("%d%d%d", &n, &m, &t);
	int x, y, r;
	while(t--)
	{
		scanf("%d%d%d", &x, &y, &r);
		for(int i = x - r; i <= x + r; ++i)
		{
			if(i < 1 || i > n)
				continue;
			for(int j = y - r; j <= y + r; ++j)
			{
				if(j < 1 || j > m)
					continue;
				if(abs(i - x) + abs(j - y) > r)
					continue;
				++cnt[i][j];
				if(cnt[i][j] > ans1)
				{
					ans1 = cnt[i][j];
					ans2 = 1;
				}
				else if(cnt[i][j] == ans1)
					++ans2;
				}
		}		
	}
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= m; j++)
		{
			cout << cnt[i][j] << ' ';
		}
		cout << endl;
	}
	printf("%d %d\n", ans1, ans2);
	return 0;
}
