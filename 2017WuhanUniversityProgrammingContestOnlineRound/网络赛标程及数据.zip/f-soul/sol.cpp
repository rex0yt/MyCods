#include <bits/stdc++.h>
using namespace std;
const int N = 2010;
int cnt[N][N];
int n, m, t;
int ans1, ans2;
void calc()
{
	for(int x = 1; x <= n; ++x)
		for(int y = 1; y <= m; ++y)
			cnt[x][y] +=  cnt[x - 1][y - 1];
	for(int x = 1; x <= n; ++x)
		for(int y = m; y; --y)
		{
			cnt[x][y] +=  cnt[x - 1][y + 1];
			if(cnt[x][y] > ans1)
			{
				ans1 = cnt[x][y];
				ans2 = 1;
			}
			else if(cnt[x][y] == ans1)
				++ans2;
		}
}
int main()
{
	//freopen("5.in", "r", stdin);
	//freopen("5.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &t);
	int x, y, r, ax, ay, bx, by;
	while(t--)
	{
		scanf("%d%d%d", &x, &y, &r);
		ax = x - r;
		ay = y - r;
		bx = x + r;
		by = y + r;
		++cnt[ax][y];
		--cnt[x + 1][by + 1];
		--cnt[x + 1][ay - 1];
		++cnt[bx + 2][y];
		if(r)
		{
			++cnt[ax + 1][y];
			--cnt[x + 1][by];
			--cnt[x + 1][ay];
			++cnt[bx + 1][y];
		}
	}
	calc();
	printf("%d %d\n", ans1, ans2);
	return 0;
}
