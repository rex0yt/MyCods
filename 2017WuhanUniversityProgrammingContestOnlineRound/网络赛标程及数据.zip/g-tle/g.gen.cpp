#include <bits/stdc++.h>

using namespace std;

int main(int argc, char **argv)
{
	random_device rd;
	int n = atoi(argv[1]);
	int cas = atoi(argv[2]);
	char buf[1024];
	sprintf(buf, "tle%d.in", cas);
	ofstream fout(buf);
	fout << n << endl;
	for (int i = 1; i <= n; i++)
		fout << rd() % 1000000 + 1 << (" \n"[i == n]);
	return 0;
}
