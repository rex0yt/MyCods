#include <bits/stdc++.h>
using namespace std;

const int maxn = 1000000 + 5;

int arr[maxn], arr2[maxn], buf[maxn];
long long ans = 0;

void merge_sort(int l, int r)
{
	if (l == r) return;
	int mid = (l + r) / 2;
	merge_sort(l, mid);
	merge_sort(mid + 1, r);
	int qh1 = l, qh2 = mid + 1, rsp = l;
	while (qh1 <= mid || qh2 <= r)
	{
		if (qh1 <= mid && (qh2 > r || arr[qh1] <= arr[qh2]))
		{
			buf[rsp++] = arr[qh1++];
			ans += qh2 - (mid + 1);
		} else
		{
			buf[rsp++] = arr[qh2++];
		}
	}
	for (int i = l; i <= r; i++) arr[i] = buf[i];
}

int main()
{
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		cin >> arr[i];
		arr2[i] = arr[i];
	}
	merge_sort(1, n);
	cout << ans << endl;
	if (0)
	{
		long long ans2 = 0;
		for (int i = 1; i <= n; i++)
			for (int j = 0; j <= n - 1; j++)
			{
				if (arr2[j] > arr2[j + 1])
				{
					ans2++;
					swap(arr2[j], arr2[j + 1]);
				}
			}
		cerr << ans << ' ' << ans2 << endl;
		assert(ans == ans2);
	}
	return 0;
}
