#include <bits/stdc++.h>

using namespace std;

const int MAGIC = 300;
const int maxn = 2e5;
long long a[maxn], m[maxn], cur_min[maxn / MAGIC], his_min[maxn / MAGIC], lazy[maxn / MAGIC], lazy2[maxn / MAGIC];
int n;

long long inblock(int num_block, int l, int r, int delta) {
  for (int i = num_block * MAGIC, last = min(n, (num_block + 1) * MAGIC); i < last; ++i) {
		m[i] = min(m[i], a[i] + lazy2[num_block]);
    a[i] += lazy[num_block];
  }
  lazy[num_block] = lazy2[num_block] = 0;
  for (int i = num_block * MAGIC + l, last = num_block * MAGIC + r; i <= last; ++i) {
    a[i] += delta;
    m[i] = min(m[i], a[i]);
  }
  cur_min[num_block] = a[num_block * MAGIC];
  for (int i = num_block * MAGIC + 1, last = min(n, (num_block + 1) * MAGIC); i < last; ++i) {
    cur_min[num_block] = min(cur_min[num_block], a[i]);
  	his_min[num_block] = min(his_min[num_block], m[i]);
	}
  long long ret = m[num_block * MAGIC + r];
  for (int i = num_block * MAGIC + l, last = num_block * MAGIC + r; i <= last; ++i) {
    ret = min(ret, m[i]);
  }
  return ret;
}

long long wholeblock(int num_block, int delta) {
  lazy[num_block] += delta;
	lazy2[num_block] = min(lazy2[num_block], lazy[num_block]);
  cur_min[num_block] += delta;
	his_min[num_block] = min(his_min[num_block], cur_min[num_block]);
  return his_min[num_block];
}

int main() {
  cin >> n;
  for (int i = 0; i <= (n - 1) / MAGIC; ++i) {
    cur_min[i] = 2e9;
  }
  for (int i = 0; i < n; ++i) {
    cin >> a[i];
    m[i] = a[i];
    cur_min[i / MAGIC] = min(cur_min[i / MAGIC], a[i]);
  }
  for (int i = 0; i <= (n - 1) / MAGIC; ++i) {
    his_min[i] = cur_min[i];
  }
  int tt, l, r, t;
  cin >> tt;
  while (tt--) {
    cin >> l >> r >> t;
    --l;
    --r;
    if (l / MAGIC == r / MAGIC) {
      cout << inblock(l / MAGIC, l % MAGIC, r % MAGIC, t) << endl;
    } else {
      long long ret = min(inblock(l / MAGIC, l % MAGIC, MAGIC - 1, t), inblock(r / MAGIC, 0, r % MAGIC, t));
      for (int i = l / MAGIC + 1; i < r / MAGIC; ++i) {
        ret = min(ret, wholeblock(i, t));
      }
      cout << ret << endl;
    }
  }
  return 0;
}
